<template>
    
</template>

<script>
    
    export default {
        data: function () {
            return {
                video_link: '',
            }
        },
        
        props: ['lesson', 'vtype'],
        
        methods: {
            
        },
        
        mounted() {
            
        }
        
        
    }
    
    
</script>